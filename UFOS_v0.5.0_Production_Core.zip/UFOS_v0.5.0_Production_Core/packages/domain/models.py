from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
from enum import Enum

class PaymentStatus(str, Enum):
    CREATED="CREATED"; PENDING="PENDING"; SUCCEEDED="SUCCEEDED"
    FAILED="FAILED"; REFUNDED="REFUNDED"

class OrderStatus(str, Enum):
    PENDING_RISK="PENDING_RISK"; ACCEPTED="ACCEPTED"; PARTIALLY_FILLED="PARTIALLY_FILLED"
    FILLED="FILLED"; CANCELLED="CANCELLED"; REJECTED="REJECTED"

@dataclass(frozen=True)
class Money:
    amount: Decimal
    currency: str

@dataclass(frozen=True)
class LedgerEntry:
    id: str
    transaction_id: str
    account_id: str
    debit: Decimal
    credit: Decimal
    currency: str
    occurred_at: datetime
