from fastapi.testclient import TestClient
from services.api import app
client=TestClient(app)

def test_health():
    r=client.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_tenant():
    r=client.post("/api/v1/tenants",json={"legal_name":"Example Holdings","display_name":"Example"})
    assert r.status_code==200
    assert r.json()["status"]=="PENDING"
