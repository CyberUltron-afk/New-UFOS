# UFOS v0.5.0 — Production Core

Multi-tenant financial infrastructure for payments, wallets, ledger, treasury,
liquidity, trading, settlement, risk and audit.

This repository is production-integration ready. External financial rails require
real provider credentials, approved contracts, compliance configuration and
operational validation before live money movement is enabled.

## Run locally
```bash
cp .env.example .env
docker compose up --build
```

API: http://localhost:8000
Health: GET /health
