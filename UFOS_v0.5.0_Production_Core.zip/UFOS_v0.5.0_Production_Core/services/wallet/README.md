# Wallet
Wallet ownership, addresses, signing/custody integration and blockchain monitoring.
Private keys must never be stored in source code or browser storage.
