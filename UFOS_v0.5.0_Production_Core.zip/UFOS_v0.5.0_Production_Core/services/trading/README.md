# Trading
Extensible support for crypto, FX, equities, bonds, commodities, ETFs and custom
instruments. Execution occurs through venue adapters after risk approval.
