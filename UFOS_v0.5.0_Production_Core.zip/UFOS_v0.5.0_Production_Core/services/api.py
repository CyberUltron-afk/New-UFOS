from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from decimal import Decimal
from datetime import datetime, timezone
from uuid import uuid4

app = FastAPI(title="UFOS Production Core API", version="0.5.0")

def now(): return datetime.now(timezone.utc)

class TenantCreate(BaseModel):
    legal_name: str = Field(min_length=2)
    display_name: str = Field(min_length=2)

class PaymentIntentCreate(BaseModel):
    tenant_id: str
    merchant_id: str
    amount: Decimal = Field(gt=0)
    currency: str = Field(min_length=3, max_length=12)
    accepted_rails: list[str] = []

class AssetCreate(BaseModel):
    symbol: str
    name: str
    asset_class: str
    network: str | None = None
    contract_address: str | None = None
    decimals: int | None = None

class OrderCreate(BaseModel):
    tenant_id: str
    instrument: str
    side: str
    order_type: str
    quantity: Decimal = Field(gt=0)
    limit_price: Decimal | None = None

tenants, payments, assets, orders, ledger_entries = {}, {}, {}, {}, []

@app.get("/health")
def health():
    return {"status":"ok","service":"ufos-core","version":"0.5.0","timestamp":now()}

@app.post("/api/v1/tenants")
def create_tenant(req: TenantCreate):
    tenant_id = str(uuid4())
    item = {"id":tenant_id, **req.model_dump(),"status":"PENDING","created_at":now()}
    tenants[tenant_id] = item
    return item

@app.post("/api/v1/payments/intents")
def create_payment(req: PaymentIntentCreate):
    payment_id = str(uuid4())
    item = {"id":payment_id,**req.model_dump(),"status":"CREATED","created_at":now()}
    payments[payment_id] = item
    return item

@app.post("/api/v1/assets")
def create_asset(req: AssetCreate):
    asset_id = str(uuid4())
    item = {"id":asset_id,**req.model_dump(),"status":"PENDING_REVIEW","created_at":now()}
    assets[asset_id] = item
    return item

@app.post("/api/v1/orders")
def create_order(req: OrderCreate):
    if req.side not in {"BUY","SELL"}:
        raise HTTPException(400,"side must be BUY or SELL")
    order_id = str(uuid4())
    item = {"id":order_id,**req.model_dump(),"status":"PENDING_RISK","created_at":now()}
    orders[order_id] = item
    return item

@app.get("/api/v1/tenants")
def list_tenants(): return list(tenants.values())

@app.get("/api/v1/payments")
def list_payments(): return list(payments.values())

@app.get("/api/v1/assets")
def list_assets(): return list(assets.values())

@app.get("/api/v1/orders")
def list_orders(): return list(orders.values())

@app.get("/api/v1/ledger")
def list_ledger(): return ledger_entries
