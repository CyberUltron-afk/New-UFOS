# Ledger
Double-entry financial source of truth. Every posting must balance debits and credits.
