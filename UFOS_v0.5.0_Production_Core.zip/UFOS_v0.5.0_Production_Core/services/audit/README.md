# Audit
Immutable audit events for administrative and financial actions with actor, tenant,
timestamp, action, object and correlation ID.
