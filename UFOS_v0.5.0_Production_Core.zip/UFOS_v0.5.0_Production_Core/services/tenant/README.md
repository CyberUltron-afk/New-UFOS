# Tenant
Tenant applications, approval, provisioning, users, roles, entitlements and isolation.
