# Payment Gateway
Hosted checkout, payment intents, card/bank/crypto/stablecoin adapters,
refunds, webhooks and reconciliation. Provider credentials belong in a secrets
manager, never in source code.
