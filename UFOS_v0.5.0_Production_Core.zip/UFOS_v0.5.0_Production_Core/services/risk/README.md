# Risk
Payment and pre-trade controls including limits, velocity, exposure, liquidity,
slippage, withdrawal controls and emergency kill switch.
