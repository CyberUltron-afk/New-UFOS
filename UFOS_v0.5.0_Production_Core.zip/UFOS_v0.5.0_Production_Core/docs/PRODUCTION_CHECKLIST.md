# Production Checklist

- [ ] PostgreSQL migrations and backups
- [ ] Secrets manager
- [ ] TLS
- [ ] IAM/RBAC/MFA
- [ ] Tenant isolation tests
- [ ] Double-entry ledger reconciliation
- [ ] Payment provider configuration
- [ ] Blockchain/RPC configuration
- [ ] Wallet/custody architecture
- [ ] KYC/KYB, AML and sanctions controls where required
- [ ] Trading venue permissions
- [ ] Pre-trade risk
- [ ] Withdrawal approvals
- [ ] Audit retention
- [ ] Monitoring and alerting
- [ ] Disaster recovery
- [ ] Legal/regulatory review
