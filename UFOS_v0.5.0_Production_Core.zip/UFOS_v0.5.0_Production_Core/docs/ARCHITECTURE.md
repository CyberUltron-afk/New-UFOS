# UFOS v0.5 Architecture

Customer -> Payment Gateway -> Risk -> External Provider -> Ledger -> Wallet/Treasury -> Settlement

Tenant -> Trading Account -> Risk -> Order Management -> Venue Router -> External Venue -> Fill -> Ledger -> Position

Custom Contract -> Verification -> Asset Registry -> Liquidity Pool -> Risk Approval -> Trading Enablement

The ledger is the authoritative financial record. Application balances must not be
mutated independently of balanced ledger transactions.
