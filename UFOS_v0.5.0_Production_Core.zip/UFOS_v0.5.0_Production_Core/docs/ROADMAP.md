# Roadmap
v0.5 Production core architecture
v0.6 Persistent repositories, migrations, IAM/RBAC and event bus
v0.7 Payment and blockchain adapters
v0.8 Wallet/custody, treasury, reconciliation and liquidity integrations
v0.9 Trading venue adapters and settlement
v1.0 Production release after security, provider and compliance validation
