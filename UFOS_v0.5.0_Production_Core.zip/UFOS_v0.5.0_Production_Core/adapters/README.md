# External Adapters
Production adapters for payment processors, banks, blockchain/RPC providers,
crypto exchanges, DEXs and securities venues. Never commit provider secrets.
